import os
import random as ran
import pygame as pg
import time
import turtle as tur
from PIL import Image

#Size varibles for image
new_height = 600
new_width = 600
#Opens image
ori_image=Image.open("Space.gif")
#resizes image
resize_image = ori_image.resize((new_width, new_height))
resize_image.save("resized_space.gif")

tur.fd(0)
#Sets animation speed
tur.speed(0)
#Change background color
tur.bgcolor("black")
#Change window title
tur.title("SpaceWar")
#adds background image
tur.bgpic("resized_space.gif")
#Hides default turtle
tur.ht()
#saves memory
tur.setundobuffer(1)
#speeds up drawing
tur.tracer(0)

class Sprite(tur.Turtle):
    def __init__(self, spriteshape, color, startx, starty):
        tur.Turtle.__init__(self, shape = spriteshape)
        self.speed(0)
        self.penup()
        self.color(color)
        self.fd(0)
        self.goto(startx,starty)
        self.speed = 1

    def move(self):
        self.fd(self.speed)

    #Boundry detection
        if self.xcor() > 295:
            self.setx(295)
            self.rt(60)
        if self.xcor() < -295:
            self.setx(-295)
            self.rt(60)
        if self.ycor() > 295:
            self.sety(295)
            self.rt(60)
        if self.ycor() < -295:
            self.sety(-295)
            self.rt(60)

    def is_collision(self, other):
        if (self.xcor() >= (other.xcor() - 15)) and \
        (self.xcor() <= (other.xcor() + 15)) and \
        (self.ycor() >= (other.ycor() - 15)) and \
        (self.ycor() <= (other.ycor() + 15)):
            return True
        else:
            return False

class Player(Sprite):
    def __init__(self, spriteshape, color, startx, starty):
        Sprite.__init__(self, spriteshape, color, startx, starty)
        self.shapesize(stretch_wid=.8, stretch_len=1.2, outline=None)
        self.speed = 4
        self.lives = 3
    #turns left
    def turn_left(self):
        self.lt(45)
    #turns right
    def turn_right(self):
        self.rt(45)
    #accelerates
    def accelerate(self):
        self.speed += 1
    #decelerate
    def decelerate(self):
        self.speed -= 1

class Enemy(Sprite):
    def __init__(self, spriteshape, color, startx, starty):
        Sprite.__init__(self, spriteshape, color, startx, starty)

        self.speed = 6
        self.setheading(ran.randint(0,360))

class Missile(Sprite):
    def __init__(self, spriteshape, color, startx, starty):
        Sprite.__init__(self, spriteshape, color, startx, starty)

        self.shapesize(stretch_wid=0.3, stretch_len=0.3, outline=None)
        self.speed = 20
        self.status = "ready"
        self.goto(-1000,1000)

    def fire(self):
        if self.status == "ready":
            play_sound("laser.mp3")
            self.goto(player.xcor(), player.ycor())
            self.setheading(player.heading())
            self.status = "fire"

    def move(self):

        if self.status == "ready":
            self.goto(-1000,1000)
        
        if self.status == "fire":
            self.fd(self.speed)

        #Border Check
        if self.xcor()<-295 or self.xcor()>295 or \
           self.ycor()<-295 or self.ycor()>295:
            self.goto(-1000,1000)
            self.status = "ready"
         
class Ally(Sprite):
    def __init__(self, spriteshape, color, startx, starty):
        Sprite.__init__(self, spriteshape, color, startx, starty)

        self.speed = 8
        self.setheading(ran.randint(0,360))

        def move(self):
            self.fd(self.speed)

    #Boundry detection
        if self.xcor() > 295:
            self.setx(295)
            self.lt(60)
        if self.xcor() < -295:
            self.setx(-295)
            self.lt(60)
        if self.ycor() > 295:
            self.sety(295)
            self.lt(60)
        if self.ycor() < -295:
            self.sety(-295)
            self.lt(60)

class Particle(Sprite):
    def __init__(self, spriteshape, color, startx, starty):
        Sprite.__init__(self, spriteshape, color, startx, starty)
        self.shapesize(stretch_wid=0.25, stretch_len=0.25, outline=None)
        self.goto(-1000,1000)
        self.frame = 0

    def explode(self, startx, starty):
        self.goto(startx, starty)
        self.setheading(ran.randint(0,360))
        self.frame = 1 

    def move(self):
        if self.frame > 0:
            self.fd(10)
            self.frame +=1

        if self.frame > 15:
            self.frame = 0
            self.goto(-1000,1000)
        
    

class Game():
    def __init__(self):
        self.level = 1
        self.score = 0
        self.state = "playing"
        self.pen = tur.Turtle()
        self.lives = 3

    def draw_border(self):
        #Draw boarder
        self.pen.speed(0)
        self.pen.color("white")
        self.pen.pensize(3)
        self.pen.penup()
        self.pen.goto(-300,300)
        self.pen.pendown()
        for side in range(4):
            self.pen.fd(600)
            self.pen.rt(90)
        self.pen.penup()
        self.pen.ht()
        self.pen.pendown()

    def show_status(self):
        self.pen.undo()
        msg = "Score: %s"%(self.score)
        self.pen.goto(-260,260)
        self.pen.write(msg, font= ("Arial", 16, "normal"))

#Creates Sound
pg.init()

def play_sound(file_path):
    pg.mixer.init()
    pg.mixer.music.load(file_path)
    pg.mixer.music.play()
    
#Create game Object
game = Game()
game.draw_border()
#Show game Status
game.show_status()
                 

#Create Sprites
player = Player("turtle", "green", 0, 0)
#enemy = Enemy("circle", "red", -100, 0)
missile = Missile("circle", "yellow", 0, 0)
#ally = Ally("square","blue",100,0)

enemies=[]
for i in range (6):
    enemies.append(Enemy("circle", "red", -100, 0))

allies=[]
for i in range (6):
    allies.append(Ally("square","blue",100,0))

particles = []
for i in range (12):
    particles.append(Particle("circle", "red",0,0))    

#Keyboard binding
tur.onkey(player.turn_left, "Left")
tur.onkey(player.turn_right, "Right")
tur.onkey(player.accelerate, "Up")
tur.onkey(player.decelerate, "Down")
tur.onkey(missile.fire, "space")
tur.listen()

#Main game loop
while True:
    tur.update()
    time.sleep(0.04)
    
    player.move()
    missile.move()

    for enemy in enemies:
        enemy.move()

    #Check for a collision between enemy and missile
        if missile.is_collision(enemy):
            play_sound("explosion.mp3")
            x = ran.randint(-295, 295)
            y = ran.randint(-295, 295)
            enemy.goto(x,y)
            missile.status = "ready"
        # Increase score
            game.score += 100
            game.show_status()
        # Do the explosion
            for particle in particles:
                particle.explode(missile.xcor(), missile.ycor())
                
        #Check for  a collision with the player
        if player.is_collision(enemy):
            play_sound("explosion.mp3")
            x = ran.randint(-295, 295)
            y = ran.randint(-295, 295)
            enemy.goto(x,y)
            game.score -= 100
            game.show_status()
        
    for ally in allies:
        ally.move()
           #Check for a collision between ally and missile
        if missile.is_collision(ally):
            play_sound("explosion.mp3")
            x = ran.randint(-295, 295)
            y = ran.randint(-295, 295)
            ally.goto(x,y)
            missile.status = "ready"
        #Decrease Score
            game.score -= 50
            game.show_status()

        for particle in particles:
            particle.move()


   


delay = input("Press enter to finish. >")
